#ifndef JCONFIG_INCLUDED
#  ifdef _WIN32
#    include "jconfig.vc"
#  else /* !_WIN32 */
#    include "jconfig.st"
#  endif /* !_WIN32 */
#endif /* JCONFIG_INCLUDED */
