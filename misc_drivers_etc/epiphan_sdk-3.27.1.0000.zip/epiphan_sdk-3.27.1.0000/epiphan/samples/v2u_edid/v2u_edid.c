/****************************************************************************
 *
 * $Id: v2u_edid.c 8841 2010-02-18 21:53:18Z pzeldin $
 *
 * Copyright (C) 2007-2008 Epiphan Systems Inc. All rights reserved.
 *
 * Reads and writes EDID information
 *
 ****************************************************************************/

#include <string.h>
#include "v2u_sys.h"
#include "v2u_util.h"

#ifdef _WIN32
#  define EDID_READ_FILE_MODE "rt"
#  define EDID_WRITE_FILE_MODE "wt"
#else
#  define EDID_READ_FILE_MODE "r"
#  define EDID_WRITE_FILE_MODE "w"
#endif

/**
 * Entry point of the application
 */
int main(int argc, char* argv[])
{
    int rc = 0;
    if (argc > 2) {
        printf("Usage: v2u_edid [file]\n");
        printf("If no file name is given, EDID is read and dumped to stdout.\n");
        printf("Otherwise, it's read from the file and written to the device.\n");
    } else {
        V2U_BOOL set_edid = V2U_FALSE;
        V2U_DRIVER_HANDLE d;
        V2UPropertyValue value;

        if (argc == 2) {
            /* Parse the EDID file */
            const char* fname = argv[1];
            FILE* f = fopen(fname, EDID_READ_FILE_MODE);
            if (f) {
                set_edid = v2u_edid_read(f, value.edid);
                fclose(f);
                if (!set_edid) {
                    printf("Failed to parse %s\n",fname);
                    return 1;
                }
            } else {
                printf("Failed to open %s\n",fname);
                return 1;
            }
        }

        /* Open the driver */
        d = v2u_open_driver();
        if (d) {
            if (set_edid) {
                /* Upload EDID to the device */
                if (v2u_set_property(d, V2UKey_EDID, &value)) {
                    printf("EDID uploaded successfully\n");
                } else {
                    printf("Failed to upload EDID to the device.\n");
                    rc = 3;
                }
            } else {
                /* Read EDID from the device */
                memset(value.edid, 0, sizeof(value.edid));
                if (v2u_get_property(d, V2UKey_EDID, &value)) {
                    /* And dump it to stdout */
                    v2u_edid_write(stdout, value.edid);
                } else {
                    printf("Unable to download EDID from the device.\n");
                    rc = 3;
                }
            }
            v2u_close_driver(d);
        } else {
            printf("No Epiphan frame grabber found\n");
            rc = 2;
        }
    }
    return rc;
}

/*
 * Local Variables:
 * c-basic-offset: 4
 * indent-tabs-mode: nil
 * End:
 */
