/****************************************************************************
 *
 * $Id: main.cpp 12965 2011-05-01 15:59:42Z monich $
 *
 * Copyright (C) 2009-2011 Epiphan Systems Inc. All rights reserved.
 *
 * Application entry point
 *
 ****************************************************************************/

#include <QtGui/QApplication>
#include "grabmainwindow.h"

int main(int argc, char *argv[])
{
    FrmGrabNet_Init();

    QApplication app(argc, argv);
    app.setOrganizationName("Epiphan Systems Inc.");
    app.setApplicationName("Frame grabber application");
    GrabMainWindow mainWindow;
    mainWindow.show();
    int ret = app.exec();

    FrmGrabNet_Deinit();
    return ret;
}
