/****************************************************************************
 *
 * $Id: grabframe.cpp 8310 2009-12-23 21:41:06Z monich $
 *
 * Copyright (C) 2009 Epiphan Systems Inc. All rights reserved.
 *
 * A single frame. Keeps a reference to the FrameGrabber object
 *
 ****************************************************************************/

#include "grabframe.h"
#include "framegrabber.h"

Frame::Frame(FrameGrabber* aGrabber, V2U_GrabFrame2* aFrame) :
    iGrabber(aGrabber->ref()),
    iFrame(aFrame)
{
    iRefCount = 1;
}

Frame::~Frame()
{
    iGrabber->release(this);
    iGrabber->deref();
}

// Increments the retain count
Frame* Frame::ref()
{
   iRefCount.ref();
   return this;
}

// Decrements the retain count
void Frame::deref()
{
    Q_ASSERT(int(iRefCount) > 0);
    if (!iRefCount.deref()) {
        delete this;
    }
}
