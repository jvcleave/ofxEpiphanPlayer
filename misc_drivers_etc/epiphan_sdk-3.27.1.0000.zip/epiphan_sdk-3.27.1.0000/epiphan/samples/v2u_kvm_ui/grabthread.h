/****************************************************************************
 *
 * $Id: grabthread.h 10622 2010-08-14 10:57:15Z monich $
 *
 * Copyright (C) 2009-2010 Epiphan Systems Inc. All rights reserved.
 *
 * Capture thread
 *
 ****************************************************************************/

#ifndef EPIPHAN_GRABTHREAD_H
#define EPIPHAN_GRABTHREAD_H

#include <QMutex>
#include <QEvent>
#include <QThread>

#include "grabevent.h"

class GrabThread : public QThread
{
    Q_OBJECT

public:
    explicit GrabThread(QObject* aReceiver);
    ~GrabThread();

    void connectGrabber(const QString& aAddress);

    bool sendMouseEvent(int aDeltaX, int aDeltaY, bool aLeft, bool aRight);
    bool sendKeyEvent(int aKey, bool aDown);
    bool sendKeyEvents(const PS2KeyPress* aKeyPresses, int aCount);

    bool getGrabParams(V2U_GrabParameters* aGp, V2UAdjRange* aRange);
    void setGrabParams(const V2U_GrabParameters& aGp);
    int setGrabDelay(int aDelay);

protected:
    void run();
    bool event(QEvent* aEvent);
    void timerEvent(QTimerEvent* aEvent);

private:
    void grabFrameEvent();
    void grabberCheckEvent();
    void grabConnectEvent(GrabConnectEvent* aEvent);
    void grabDisconnectEvent(GrabEvent* aEvent);
    void grabSetParametersEvent(GrabSetParametersEvent* aEvent);
    void grabUpdateDelayEvent();

    void openGrabber();
    void setupGrabber();
    void queryGrabParams();
    void closeGrabber();
    bool detectVideoMode();
    bool updateVideoMode(const V2U_VideoMode* aVideoMode);

private:
    QMutex iMutex;
    QObject* iReceiver;
    FrameGrabber* iGrabber;
    V2U_VideoMode iVideoMode;
    V2U_GrabParameters iGp;
    V2UAdjRange iRange;
    int iGrabFrameTimerId;
    int iUpdateParamsTimerId;
    int iSlowGrabFrameTimerId;
    int iSignalCheckTimerId;
    int iGrabberCheckTimerId;
    int iErrCount;
    int iGrabDelay;
};

#endif // EPIPHAN_GRABTHREAD_H

/*
 * Local Variables:
 * c-basic-offset: 4
 * indent-tabs-mode: nil
 * End:
 */
