/****************************************************************************
 *
 * $Id: grabevent.cpp 8310 2009-12-23 21:41:06Z monich $
 *
 * Copyright (C) 2009 Epiphan Systems Inc. All rights reserved.
 *
 * Application specific events
 *
 ****************************************************************************/

#include "grabevent.h"
#include "grabframe.h"

GrabEvent::GrabEvent(GrabEventType aType, FrameGrabber* aGrabber) :
    QEvent(QEvent::Type(aType))
{
    iGrabber = aGrabber->ref();
}

GrabEvent::~GrabEvent()
{
    iGrabber->deref();
}

GrabEvent* GrabEvent::createOpenEvent(FrameGrabber* aGrabber)
{
    return new GrabEvent(GrabEventOpen, aGrabber);
}

GrabEvent* GrabEvent::createCloseEvent(FrameGrabber* aGrabber)
{
    return new GrabEvent(GrabEventClose, aGrabber);
}

GrabVideoModeEvent* GrabEvent::createVideoModeEvent(FrameGrabber* aGrabber,
    const V2U_VideoMode* aVideoMode)
{
    return new GrabVideoModeEvent(aGrabber, aVideoMode);
}

GrabFrameEvent* GrabEvent::createFrameEvent(FrameGrabber* aGrabber,
    Frame* aFrame)
{
    return new GrabFrameEvent(aGrabber, aFrame);
}

// GrabVideoModeEvent
GrabVideoModeEvent::GrabVideoModeEvent(FrameGrabber* aGrabber,
    const V2U_VideoMode* aVideoMode) :
    GrabEvent(GrabEventVideoMode, aGrabber)
{
    if (aVideoMode) {
        iVideoMode = *aVideoMode;
    } else {
        memset(&iVideoMode, 0, sizeof(iVideoMode));
    }
}

// GrabFrameEvent
GrabFrameEvent::GrabFrameEvent(FrameGrabber* aGrabber, Frame* aFrame) :
    GrabEvent(GrabEventFrame, aGrabber),
    iFrame(aFrame->ref())
{
}

GrabFrameEvent::~GrabFrameEvent()
{
    iFrame->deref();
}

/*
 * Local Variables:
 * c-basic-offset: 4
 * indent-tabs-mode: nil
 * End:
 */
