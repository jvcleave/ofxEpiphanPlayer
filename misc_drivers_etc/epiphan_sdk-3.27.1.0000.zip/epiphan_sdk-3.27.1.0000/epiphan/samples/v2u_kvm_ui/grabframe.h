/****************************************************************************
 *
 * $Id: grabframe.h 8310 2009-12-23 21:41:06Z monich $
 *
 * Copyright (C) 2009 Epiphan Systems Inc. All rights reserved.
 *
 * A single frame. Keeps a reference to the FrameGrabber object
 *
 ****************************************************************************/

#ifndef EPIPHAN_GRABFRAME_H
#define EPIPHAN_GRABFRAME_H

#include <QBasicAtomicInt>
#include "frmgrab.h"

class FrameGrabber;

class Frame
{
    friend class FrameGrabber;

protected:
    Frame(FrameGrabber* aGrabber, V2U_GrabFrame2* aFrame);

private:
    // Destructor is private because Frame is a ref-counted object
    ~Frame();

public:
    Frame* ref();
    void deref();

    inline const V2U_GrabFrame2* frame() const;
    inline int width() const;
    inline int height() const;

private:
    QBasicAtomicInt iRefCount;
    FrameGrabber* iGrabber;
    V2U_GrabFrame2* iFrame;
};

// Inline methods
inline const V2U_GrabFrame2* Frame::frame() const { return iFrame; }
inline int Frame::width() const { return iFrame->crop.width; }
inline int Frame::height() const { return iFrame->crop.height; }

#endif // EPIPHAN_GRABFRAME_H
